<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class FavController extends Controller
{
    //
}
