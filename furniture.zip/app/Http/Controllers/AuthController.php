<?php

namespace App\Http\Controllers;

use App\Http\Requests\Auth\LoginUser;
use App\Http\Requests\Auth\RegisterUser;
use App\Models\User;
use Illuminate\Support\Facades\Auth;

class AuthController extends Controller
{

    /* Register a new user */
    public function register(RegisterUser $request)
    {
        $user = User::create($request->validated());
        uploadImage($request['image'], $user, 'userImages');
        return shoeMessage('auth/messages.auth_success', $user, 'UserResource', true);
    }


    /* Login a  user */
    public function login(LoginUser $request)
    {
        if (!Auth::attempt($request->only(['email', 'password']))) {
            return shoeMessage('auth/messages.auth_error', null,null, false);
        }
        $user = User::where('email', $request->email)->first();
        return shoeMessage('auth/messages.auth_success', $user, 'UserResource', true);
    }


}
