<?php

return [

    'required' => 'The  field is required.',
    'string' => 'The  field is string ',
    'min' => 'The  field must be at least :n characters  ',
    'max' => 'The name field must not be greater than :n characters',
    'email'=>'The email field must be a valid email address',
    'confirmed'=>'The password field confirmation does not match'

];
